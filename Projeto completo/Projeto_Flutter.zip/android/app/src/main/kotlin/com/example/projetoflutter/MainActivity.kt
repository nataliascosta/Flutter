package com.example.projetoflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
